<?php $this->load->view('template/headerHome'); ?>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<div class="offers">
	<div class="container">
		<div class="row">
			<div class="col text-center">
				<h2 class="section_title">Contact</h2>
			</div>
		</div>
		<div class="row offers_items text-center">
			<table class="table">
				<tr>
					<td class="text-right">Alamat</td>
					<td class="text-left">Jl Soekarno Hatta No 5 Malang</td>
				</tr>
				<tr>
					<td class="text-right">Telp</td>
					<td class="text-left">0351-443-443</td>
				</tr>
				<tr>
					<td class="text-right">Email</td>
					<td class="text-left">cs@aai.com</td>
				</tr>
				<tr>
					<td class="text-right">Facebook</td>
					<td class="text-left">AAI Express</td>
				</tr>	
				<tr>
					<td class="text-right">Twitter</td>
					<td class="text-left">@aai_express</td>
				</tr>
				<tr>	
					<td class="text-right">Instagram</td>
					<td class="text-left">@aai_express</td>
				</tr>
			</table>
		</div>
	</div>
</div>

<?php $this->load->view('template/footerHome'); ?>