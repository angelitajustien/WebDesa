## :beginner: Codeigniter Expedisi :beginner:

### Dibuat Oleh	: 	
	- Idris Cahyono
	- Angelita Justien
	- Andi Putra Wijaya
		
### System Requiretments :
	- Xampp v.3.2.2
	- Browser Chrome or Firefox

### Installation :
	- Download Project
	- Pindahkan Project Di Folder Htdocs Di Xampp Anda
	
### Configuration :
	- Jangan Lupa Rubah Configurasi Di Folder Config/Database.php Dan Config/Config.php
	  Sesuai Dengan Konfigurasi Xampp Anda

### Template By	: 
	-[colorlib] (https://colorlib.com/)
